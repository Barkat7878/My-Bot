import { db } from '@/lib/db';

const tradingPairs = [
  // ═══════════════════════ FOREX MAJORS ═══════════════════════
  { symbol: 'EUR/USD', name: 'Euro / US Dollar', category: 'forex', basePrice: 1.0856, pipSize: 0.0001 },
  { symbol: 'GBP/USD', name: 'British Pound / US Dollar', category: 'forex', basePrice: 1.2720, pipSize: 0.0001 },
  { symbol: 'USD/JPY', name: 'US Dollar / Japanese Yen', category: 'forex', basePrice: 151.85, pipSize: 0.01 },
  { symbol: 'USD/CHF', name: 'US Dollar / Swiss Franc', category: 'forex', basePrice: 0.8845, pipSize: 0.0001 },
  { symbol: 'AUD/USD', name: 'Australian Dollar / US Dollar', category: 'forex', basePrice: 0.6580, pipSize: 0.0001 },
  { symbol: 'USD/CAD', name: 'US Dollar / Canadian Dollar', category: 'forex', basePrice: 1.3620, pipSize: 0.0001 },
  { symbol: 'NZD/USD', name: 'New Zealand Dollar / US Dollar', category: 'forex', basePrice: 0.6120, pipSize: 0.0001 },

  // ═══════════════════════ FOREX MINORS ═══════════════════════
  { symbol: 'EUR/GBP', name: 'Euro / British Pound', category: 'forex', basePrice: 0.8530, pipSize: 0.0001 },
  { symbol: 'EUR/JPY', name: 'Euro / Japanese Yen', category: 'forex', basePrice: 164.85, pipSize: 0.01 },
  { symbol: 'GBP/JPY', name: 'British Pound / Japanese Yen', category: 'forex', basePrice: 193.20, pipSize: 0.01 },
  { symbol: 'EUR/CHF', name: 'Euro / Swiss Franc', category: 'forex', basePrice: 0.9602, pipSize: 0.0001 },
  { symbol: 'EUR/AUD', name: 'Euro / Australian Dollar', category: 'forex', basePrice: 1.6500, pipSize: 0.0001 },
  { symbol: 'GBP/AUD', name: 'British Pound / Australian Dollar', category: 'forex', basePrice: 1.9340, pipSize: 0.0001 },
  { symbol: 'EUR/CAD', name: 'Euro / Canadian Dollar', category: 'forex', basePrice: 1.4785, pipSize: 0.0001 },
  { symbol: 'GBP/CAD', name: 'British Pound / Canadian Dollar', category: 'forex', basePrice: 1.7325, pipSize: 0.0001 },
  { symbol: 'AUD/JPY', name: 'Australian Dollar / Japanese Yen', category: 'forex', basePrice: 99.95, pipSize: 0.01 },
  { symbol: 'CHF/JPY', name: 'Swiss Franc / Japanese Yen', category: 'forex', basePrice: 171.70, pipSize: 0.01 },
  { symbol: 'NZD/JPY', name: 'New Zealand Dollar / Japanese Yen', category: 'forex', basePrice: 92.95, pipSize: 0.01 },
  { symbol: 'AUD/NZD', name: 'Australian Dollar / NZ Dollar', category: 'forex', basePrice: 1.0752, pipSize: 0.0001 },
  { symbol: 'EUR/NZD', name: 'Euro / NZ Dollar', category: 'forex', basePrice: 1.7745, pipSize: 0.0001 },
  { symbol: 'GBP/CHF', name: 'British Pound / Swiss Franc', category: 'forex', basePrice: 1.1258, pipSize: 0.0001 },
  { symbol: 'AUD/CAD', name: 'Australian Dollar / Canadian Dollar', category: 'forex', basePrice: 0.8965, pipSize: 0.0001 },

  // ═══════════════════════ FOREX EXOTICS ═══════════════════════
  { symbol: 'USD/TRY', name: 'US Dollar / Turkish Lira', category: 'forex', basePrice: 36.25, pipSize: 0.01 },
  { symbol: 'USD/ZAR', name: 'US Dollar / South African Rand', category: 'forex', basePrice: 18.45, pipSize: 0.01 },
  { symbol: 'USD/MXN', name: 'US Dollar / Mexican Peso', category: 'forex', basePrice: 17.15, pipSize: 0.01 },
  { symbol: 'USD/SGD', name: 'US Dollar / Singapore Dollar', category: 'forex', basePrice: 1.3415, pipSize: 0.0001 },
  { symbol: 'USD/HKD', name: 'US Dollar / Hong Kong Dollar', category: 'forex', basePrice: 7.8245, pipSize: 0.0001 },
  { symbol: 'USD/INR', name: 'US Dollar / Indian Rupee', category: 'forex', basePrice: 83.45, pipSize: 0.01 },
  { symbol: 'USD/BRL', name: 'US Dollar / Brazilian Real', category: 'forex', basePrice: 5.15, pipSize: 0.01 },
  { symbol: 'USD/CNY', name: 'US Dollar / Chinese Yuan', category: 'forex', basePrice: 7.2450, pipSize: 0.01 },
  { symbol: 'USD/SEK', name: 'US Dollar / Swedish Krona', category: 'forex', basePrice: 10.58, pipSize: 0.01 },
  { symbol: 'USD/NOK', name: 'US Dollar / Norwegian Krone', category: 'forex', basePrice: 10.82, pipSize: 0.01 },
  { symbol: 'USD/PLN', name: 'US Dollar / Polish Zloty', category: 'forex', basePrice: 4.02, pipSize: 0.01 },
  { symbol: 'USD/THB', name: 'US Dollar / Thai Baht', category: 'forex', basePrice: 34.50, pipSize: 0.01 },
  { symbol: 'EUR/TRY', name: 'Euro / Turkish Lira', category: 'forex', basePrice: 39.38, pipSize: 0.01 },
  { symbol: 'GBP/ZAR', name: 'British Pound / South African Rand', category: 'forex', basePrice: 23.48, pipSize: 0.01 },

  // ═══════════════════════ FOREX OTC PAIRS ═══════════════════════
  { symbol: 'USD/BRL OTC', name: 'US Dollar / BRL OTC', category: 'otc', basePrice: 5.15, pipSize: 0.01 },
  { symbol: 'EUR/USD OTC', name: 'Euro / USD OTC', category: 'otc', basePrice: 1.0856, pipSize: 0.0001 },
  { symbol: 'GBP/USD OTC', name: 'British Pound / USD OTC', category: 'otc', basePrice: 1.2720, pipSize: 0.0001 },
  { symbol: 'USD/JPY OTC', name: 'US Dollar / JPY OTC', category: 'otc', basePrice: 151.85, pipSize: 0.01 },
  { symbol: 'AUD/USD OTC', name: 'Australian Dollar / USD OTC', category: 'otc', basePrice: 0.6580, pipSize: 0.0001 },
  { symbol: 'USD/CAD OTC', name: 'US Dollar / CAD OTC', category: 'otc', basePrice: 1.3620, pipSize: 0.0001 },
  { symbol: 'NZD/USD OTC', name: 'NZ Dollar / USD OTC', category: 'otc', basePrice: 0.6120, pipSize: 0.0001 },
  { symbol: 'EUR/GBP OTC', name: 'Euro / GBP OTC', category: 'otc', basePrice: 0.8530, pipSize: 0.0001 },
  { symbol: 'GBP/JPY OTC', name: 'British Pound / JPY OTC', category: 'otc', basePrice: 193.20, pipSize: 0.01 },
  { symbol: 'USD/TRY OTC', name: 'US Dollar / TRY OTC', category: 'otc', basePrice: 36.25, pipSize: 0.01 },
  { symbol: 'USD/ZAR OTC', name: 'US Dollar / ZAR OTC', category: 'otc', basePrice: 18.45, pipSize: 0.01 },
  { symbol: 'USD/MXN OTC', name: 'US Dollar / MXN OTC', category: 'otc', basePrice: 17.15, pipSize: 0.01 },

  // ═══════════════════════ CRYPTO MAJORS ═══════════════════════
  { symbol: 'BTC/USD', name: 'Bitcoin / US Dollar', category: 'crypto', basePrice: 67250.00, pipSize: 0.01 },
  { symbol: 'ETH/USD', name: 'Ethereum / US Dollar', category: 'crypto', basePrice: 3520.00, pipSize: 0.01 },
  { symbol: 'BNB/USD', name: 'Binance Coin / US Dollar', category: 'crypto', basePrice: 585.00, pipSize: 0.01 },
  { symbol: 'SOL/USD', name: 'Solana / US Dollar', category: 'crypto', basePrice: 148.50, pipSize: 0.01 },
  { symbol: 'XRP/USD', name: 'Ripple / US Dollar', category: 'crypto', basePrice: 0.6250, pipSize: 0.0001 },
  { symbol: 'ADA/USD', name: 'Cardano / US Dollar', category: 'crypto', basePrice: 0.645, pipSize: 0.0001 },
  { symbol: 'DOGE/USD', name: 'Dogecoin / US Dollar', category: 'crypto', basePrice: 0.1645, pipSize: 0.0001 },
  { symbol: 'DOT/USD', name: 'Polkadot / US Dollar', category: 'crypto', basePrice: 7.25, pipSize: 0.01 },
  { symbol: 'LINK/USD', name: 'Chainlink / US Dollar', category: 'crypto', basePrice: 15.80, pipSize: 0.01 },
  { symbol: 'MATIC/USD', name: 'Polygon / US Dollar', category: 'crypto', basePrice: 0.725, pipSize: 0.0001 },
  { symbol: 'AVAX/USD', name: 'Avalanche / US Dollar', category: 'crypto', basePrice: 35.80, pipSize: 0.01 },
  { symbol: 'UNI/USD', name: 'Uniswap / US Dollar', category: 'crypto', basePrice: 7.85, pipSize: 0.01 },

  // ═══════════════════════ CRYPTO ALT COINS ═══════════════════════
  { symbol: 'SHIB/USD', name: 'Shiba Inu / US Dollar', category: 'crypto', basePrice: 0.0000245, pipSize: 0.0000001 },
  { symbol: 'PEPE/USD', name: 'Pepe / US Dollar', category: 'crypto', basePrice: 0.0000085, pipSize: 0.0000001 },
  { symbol: 'LTC/USD', name: 'Litecoin / US Dollar', category: 'crypto', basePrice: 84.50, pipSize: 0.01 },
  { symbol: 'ATOM/USD', name: 'Cosmos / US Dollar', category: 'crypto', basePrice: 8.95, pipSize: 0.01 },
  { symbol: 'FIL/USD', name: 'Filecoin / US Dollar', category: 'crypto', basePrice: 5.85, pipSize: 0.01 },
  { symbol: 'APT/USD', name: 'Aptos / US Dollar', category: 'crypto', basePrice: 9.25, pipSize: 0.01 },
  { symbol: 'ARB/USD', name: 'Arbitrum / US Dollar', category: 'crypto', basePrice: 1.15, pipSize: 0.0001 },
  { symbol: 'OP/USD', name: 'Optimism / US Dollar', category: 'crypto', basePrice: 2.45, pipSize: 0.01 },
  { symbol: 'NEAR/USD', name: 'NEAR Protocol / US Dollar', category: 'crypto', basePrice: 5.35, pipSize: 0.01 },
  { symbol: 'INJ/USD', name: 'Injective / US Dollar', category: 'crypto', basePrice: 24.50, pipSize: 0.01 },
  { symbol: 'SUI/USD', name: 'Sui / US Dollar', category: 'crypto', basePrice: 1.85, pipSize: 0.01 },
  { symbol: 'SEI/USD', name: 'Sei / US Dollar', category: 'crypto', basePrice: 0.48, pipSize: 0.001 },
  { symbol: 'TIA/USD', name: 'Celestia / US Dollar', category: 'crypto', basePrice: 9.80, pipSize: 0.01 },
  { symbol: 'RUNE/USD', name: 'Thorchain / US Dollar', category: 'crypto', basePrice: 4.25, pipSize: 0.01 },
  { symbol: 'GRT/USD', name: 'The Graph / US Dollar', category: 'crypto', basePrice: 0.285, pipSize: 0.001 },
  { symbol: 'AAVE/USD', name: 'Aave / US Dollar', category: 'crypto', basePrice: 95.00, pipSize: 0.01 },
  { symbol: 'MKR/USD', name: 'Maker / US Dollar', category: 'crypto', basePrice: 2850.00, pipSize: 0.01 },
  { symbol: 'SNX/USD', name: 'Synthetix / US Dollar', category: 'crypto', basePrice: 3.15, pipSize: 0.01 },
  { symbol: 'COMP/USD', name: 'Compound / US Dollar', category: 'crypto', basePrice: 52.50, pipSize: 0.01 },
  { symbol: 'CRV/USD', name: 'Curve / US Dollar', category: 'crypto', basePrice: 0.42, pipSize: 0.001 },

  // ═══════════════════════ CRYPTO FIAT PAIRS ═══════════════════════
  { symbol: 'BTC/EUR', name: 'Bitcoin / Euro', category: 'crypto', basePrice: 73000.00, pipSize: 0.01 },
  { symbol: 'BTC/GBP', name: 'Bitcoin / British Pound', category: 'crypto', basePrice: 85500.00, pipSize: 0.01 },
  { symbol: 'BTC/JPY', name: 'Bitcoin / Japanese Yen', category: 'crypto', basePrice: 10210000.00, pipSize: 1 },
  { symbol: 'BTC/BRL', name: 'Bitcoin / Brazilian Real', category: 'crypto', basePrice: 346000.00, pipSize: 0.01 },
  { symbol: 'ETH/BTC', name: 'Ethereum / Bitcoin', category: 'crypto', basePrice: 0.0523, pipSize: 0.0001 },
  { symbol: 'BNB/BTC', name: 'Binance Coin / Bitcoin', category: 'crypto', basePrice: 0.0087, pipSize: 0.0001 },
  { symbol: 'SOL/BTC', name: 'Solana / Bitcoin', category: 'crypto', basePrice: 0.00221, pipSize: 0.00001 },
  { symbol: 'XRP/BTC', name: 'Ripple / Bitcoin', category: 'crypto', basePrice: 0.0000093, pipSize: 0.0000001 },

  // ═══════════════════════ COMMODITIES ═══════════════════════
  { symbol: 'XAU/USD', name: 'Gold / US Dollar', category: 'commodity', basePrice: 2345.50, pipSize: 0.01 },
  { symbol: 'XAG/USD', name: 'Silver / US Dollar', category: 'commodity', basePrice: 28.50, pipSize: 0.01 },
  { symbol: 'XPT/USD', name: 'Platinum / US Dollar', category: 'commodity', basePrice: 985.00, pipSize: 0.01 },
  { symbol: 'WTI/USD', name: 'West Texas Oil / US Dollar', category: 'commodity', basePrice: 78.50, pipSize: 0.01 },
  { symbol: 'BRENT/USD', name: 'Brent Oil / US Dollar', category: 'commodity', basePrice: 82.30, pipSize: 0.01 },
  { symbol: 'NG/USD', name: 'Natural Gas / US Dollar', category: 'commodity', basePrice: 2.15, pipSize: 0.001 },

  // ═══════════════════════ INDICES ═══════════════════════
  { symbol: 'US500/USD', name: 'S&P 500 / US Dollar', category: 'index', basePrice: 5285.50, pipSize: 0.01 },
  { symbol: 'NAS100/USD', name: 'NASDAQ 100 / US Dollar', category: 'index', basePrice: 18520.00, pipSize: 0.01 },
  { symbol: 'US30/USD', name: 'Dow Jones 30 / US Dollar', category: 'index', basePrice: 39875.00, pipSize: 0.01 },
  { symbol: 'UK100/USD', name: 'FTSE 100 / US Dollar', category: 'index', basePrice: 7950.00, pipSize: 0.01 },
  { symbol: 'DE40/USD', name: 'DAX 40 / US Dollar', category: 'index', basePrice: 18250.00, pipSize: 0.01 },
  { symbol: 'JP225/USD', name: 'Nikkei 225 / US Dollar', category: 'index', basePrice: 38500.00, pipSize: 0.01 },
];

async function seedPairs() {
  console.log(`Seeding ${tradingPairs.length} trading pairs...`);

  for (const pair of tradingPairs) {
    await db.tradingPair.upsert({
      where: { symbol: pair.symbol },
      update: {
        name: pair.name,
        category: pair.category,
        basePrice: pair.basePrice,
        pipSize: pair.pipSize,
        active: true,
      },
      create: pair,
    });
  }

  const count = await db.tradingPair.count();
  console.log(`✅ Seeded ${count} trading pairs successfully!`);

  // Print summary by category
  const categories = await db.tradingPair.groupBy({
    by: ['category'],
    _count: { symbol: true },
  });
  console.log('\n📊 Pair counts by category:');
  for (const cat of categories) {
    console.log(`  ${cat.category}: ${cat._count.symbol} pairs`);
  }
}

seedPairs()
  .catch((e) => {
    console.error('Seed error:', e);
    process.exit(1);
  })
  .finally(() => {
    process.exit(0);
  });
