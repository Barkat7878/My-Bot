import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import { getSeedHistorySignals } from '@/lib/signal-engine';

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization');
    let signals: unknown[] = [];

    if (authHeader?.startsWith('Bearer ')) {
      const token = authHeader.replace('Bearer ', '');
      const payload = await verifyToken(token);
      if (payload) {
        const userSignals = await db.signal.findMany({
          where: { userId: payload.userId },
          orderBy: { createdAt: 'desc' },
          take: 50,
        });
        signals = userSignals;
      }
    }

    // Combine with seed signals for demo purposes
    if (signals.length === 0) {
      signals = getSeedHistorySignals();
    }

    // Calculate stats
    const allSignals = signals as Array<{
      result?: string;
      direction: string;
      accuracy: number;
      profitLoss?: number;
    }>;

    const completedSignals = allSignals.filter((s) => s.result);
    const wins = completedSignals.filter((s) => s.result === 'WIN').length;
    const losses = completedSignals.filter((s) => s.result === 'LOSS').length;
    const totalCompleted = wins + losses;
    const winRate = totalCompleted > 0 ? ((wins / totalCompleted) * 100).toFixed(1) : '0';
    const totalProfit = completedSignals.reduce((acc, s) => acc + (s.profitLoss || 0), 0);

    return NextResponse.json({
      signals,
      stats: {
        total: allSignals.length,
        wins,
        losses,
        winRate: parseFloat(winRate),
        totalProfit: parseFloat(totalProfit.toFixed(2)),
        avgAccuracy: allSignals.length > 0
          ? parseFloat((allSignals.reduce((acc, s) => acc + s.accuracy, 0) / allSignals.length).toFixed(1))
          : 0,
      },
    });
  } catch (error) {
    console.error('Signal history error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
