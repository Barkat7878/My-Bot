import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const search = searchParams.get('search');

    const where: Record<string, unknown> = { active: true };
    if (category && category !== 'all') {
      where.category = category;
    }
    if (search) {
      where.OR = [
        { symbol: { contains: search } },
        { name: { contains: search } },
      ];
    }

    const pairs = await db.tradingPair.findMany({
      where,
      orderBy: [{ category: 'asc' }, { symbol: 'asc' }],
      select: {
        id: true,
        symbol: true,
        name: true,
        category: true,
        basePrice: true,
        pipSize: true,
      },
    });

    // Get category counts
    const categoryCounts = await db.tradingPair.groupBy({
      by: ['category'],
      where: { active: true },
      _count: { symbol: true },
    });

    const totalCount = await db.tradingPair.count({ where: { active: true } });

    return NextResponse.json({
      pairs,
      categories: categoryCounts.map((c) => ({
        name: c.category,
        count: c._count.symbol,
      })),
      total: totalCount,
    });
  } catch (error) {
    console.error('Pairs fetch error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
