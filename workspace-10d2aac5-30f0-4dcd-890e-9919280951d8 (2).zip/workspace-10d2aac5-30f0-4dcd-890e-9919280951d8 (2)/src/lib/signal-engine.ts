import { db } from '@/lib/db';

// AI-based Signal Generation Engine using Technical Indicators
// Generates realistic trading signals based on simulated market data

interface SignalRequest {
  broker: string;
  pair: string;
  timeframe: string;
  strategy: string;
}

interface GeneratedSignal {
  direction: 'BUY' | 'SELL';
  accuracy: number;
  riskLevel: 'Low' | 'Medium' | 'High';
  rsi: number;
  macd: number;
  macdSignal: number;
  ma20: number;
  ma50: number;
  entryPrice: number;
  confidence: number;
  pairCategory: string;
  indicators: {
    rsi: { value: number; signal: string };
    macd: { value: number; signal: string; histogram: number };
    ma: { value20: number; value50: number; signal: string };
    bollinger: { upper: number; lower: number; middle: number; position: string };
    stochastic: { k: number; d: number; signal: string };
  };
}

function seededRandom(seed: number): number {
  const x = Math.sin(seed * 9301 + 49297) * 49297;
  return x - Math.floor(x);
}

// Fallback price database for when DB is not available
const fallbackPrices: Record<string, { price: number; category: string }> = {
  'USD/BRL OTC': { price: 5.15, category: 'otc' },
  'EUR/USD': { price: 1.0856, category: 'forex' },
  'BTC/USD': { price: 67250.0, category: 'crypto' },
  'GBP/USD': { price: 1.2720, category: 'forex' },
  'USD/JPY': { price: 151.85, category: 'forex' },
  'AUD/USD': { price: 0.6580, category: 'forex' },
  'EUR/GBP': { price: 0.8530, category: 'forex' },
  'USD/CAD': { price: 1.3620, category: 'forex' },
  'NZD/USD': { price: 0.6120, category: 'forex' },
  'EUR/JPY': { price: 164.85, category: 'forex' },
  'GBP/JPY': { price: 193.20, category: 'forex' },
  'XAU/USD': { price: 2345.50, category: 'commodity' },
  'ETH/USD': { price: 3520.00, category: 'crypto' },
  'SOL/USD': { price: 148.50, category: 'crypto' },
  'XRP/USD': { price: 0.625, category: 'crypto' },
  'BNB/USD': { price: 585.00, category: 'crypto' },
  'DOGE/USD': { price: 0.1645, category: 'crypto' },
  'ADA/USD': { price: 0.645, category: 'crypto' },
  'DOT/USD': { price: 7.25, category: 'crypto' },
  'LINK/USD': { price: 15.80, category: 'crypto' },
  'AVAX/USD': { price: 35.80, category: 'crypto' },
  'LTC/USD': { price: 84.50, category: 'crypto' },
  'USD/CHF': { price: 0.8845, category: 'forex' },
  'USD/TRY': { price: 36.25, category: 'forex' },
  'USD/ZAR': { price: 18.45, category: 'forex' },
  'USD/MXN': { price: 17.15, category: 'forex' },
  'USD/SGD': { price: 1.3415, category: 'forex' },
  'USD/BRL': { price: 5.15, category: 'forex' },
  'XAG/USD': { price: 28.50, category: 'commodity' },
  'US500/USD': { price: 5285.50, category: 'index' },
  'NAS100/USD': { price: 18520.00, category: 'index' },
};

async function getPairData(symbol: string): Promise<{ price: number; category: string }> {
  try {
    const pair = await db.tradingPair.findUnique({
      where: { symbol },
      select: { basePrice: true, category: true },
    });
    if (pair) {
      return { price: pair.basePrice, category: pair.category };
    }
  } catch {
    // DB not available, use fallback
  }
  return fallbackPrices[symbol] || { price: 1.0, category: 'forex' };
}

function calculateRSI(currentRSI: number, trend: number): number {
  const change = (trend - 0.5) * 8 + (Math.random() - 0.5) * 6;
  return Math.max(5, Math.min(95, currentRSI + change));
}

function calculateMACD(price: number, seed: number): { macd: number; signal: number; histogram: number } {
  const macdBase = (seededRandom(seed) - 0.5) * 0.05;
  const signalBase = (seededRandom(seed + 1) - 0.5) * 0.03;
  const macd = macdBase * (price / 100);
  const signal = signalBase * (price / 100);
  const histogram = macd - signal;
  return { macd: parseFloat(macd.toFixed(6)), signal: parseFloat(signal.toFixed(6)), histogram: parseFloat(histogram.toFixed(6)) };
}

function calculateMA(price: number, seed: number): { ma20: number; ma50: number } {
  const variance20 = price * 0.015 * (seededRandom(seed) - 0.5);
  const variance50 = price * 0.025 * (seededRandom(seed + 1) - 0.5);
  return {
    ma20: parseFloat((price + variance20).toFixed(price > 100 ? 2 : 5)),
    ma50: parseFloat((price + variance50).toFixed(price > 100 ? 2 : 5)),
  };
}

function calculateBollinger(price: number, seed: number): { upper: number; lower: number; middle: number } {
  const middle = price;
  const bandWidth = price * 0.02;
  const upper = parseFloat((price + bandWidth * (1 + seededRandom(seed) * 0.5)).toFixed(price > 100 ? 2 : 5));
  const lower = parseFloat((price - bandWidth * (1 + seededRandom(seed + 1) * 0.5)).toFixed(price > 100 ? 2 : 5));
  return { upper, lower, middle: parseFloat(middle.toFixed(price > 100 ? 2 : 5)) };
}

function calculateStochastic(seed: number): { k: number; d: number } {
  const k = 20 + seededRandom(seed) * 60;
  const d = k + (seededRandom(seed + 1) - 0.5) * 15;
  return { k: parseFloat(k.toFixed(2)), d: parseFloat(Math.max(5, Math.min(95, d)).toFixed(2)) };
}

function determineDirection(indicators: {
  rsi: number;
  macdHist: number;
  maPosition: string;
  stochK: number;
  stochD: number;
  priceAboveMA20: boolean;
}): { direction: 'BUY' | 'SELL'; confidence: number } {
  let buyScore = 0;
  let sellScore = 0;

  if (indicators.rsi < 30) buyScore += 2;
  else if (indicators.rsi < 40) buyScore += 1;
  else if (indicators.rsi > 70) sellScore += 2;
  else if (indicators.rsi > 60) sellScore += 1;

  if (indicators.macdHist > 0) buyScore += 1.5;
  else sellScore += 1.5;

  if (indicators.maPosition === 'above') buyScore += 1;
  else sellScore += 1;

  if (indicators.stochK < 20 && indicators.stochD < 20) buyScore += 1.5;
  else if (indicators.stochK > 80 && indicators.stochD > 80) sellScore += 1.5;
  else if (indicators.stochK > indicators.stochD) buyScore += 0.5;
  else sellScore += 0.5;

  if (indicators.priceAboveMA20) buyScore += 1;
  else sellScore += 1;

  const total = buyScore + sellScore;
  const direction = buyScore >= sellScore ? 'BUY' : 'SELL';
  const confidence = total > 0 ? Math.max(55, Math.min(95, (Math.max(buyScore, sellScore) / total) * 100)) : 65;

  return { direction, confidence: parseFloat(confidence.toFixed(1)) };
}

export async function generateSignal(request: SignalRequest): Promise<GeneratedSignal> {
  const now = Date.now();
  const seed = now / 1000;
  const pairSeed = request.pair.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);

  // Get base price from database
  const { price: basePrice, category: pairCategory } = await getPairData(request.pair);
  const priceVariation = basePrice * 0.005 * (seededRandom(seed + pairSeed) - 0.5);
  const entryPrice = parseFloat((basePrice + priceVariation).toFixed(basePrice > 100 ? 2 : 5));

  // Strategy adjustments
  let trendBias = 0.5;
  if (request.strategy === 'Scalping') trendBias = 0.55 + seededRandom(seed) * 0.1;
  else if (request.strategy === 'Trend') trendBias = 0.45 + seededRandom(seed) * 0.2;
  else if (request.strategy === 'Reversal') trendBias = seededRandom(seed);

  // Category-based volatility adjustment
  const volatilityMultiplier = pairCategory === 'crypto' ? 1.3 : pairCategory === 'commodity' ? 1.1 : pairCategory === 'index' ? 0.8 : 1.0;

  // Timeframe adjustments
  const timeframeMultiplier = request.timeframe === '5s' ? 0.7 : request.timeframe === '10s' ? 0.85 : request.timeframe === '30s' ? 1.0 : 1.15;

  // Calculate all indicators
  const rsi = calculateRSI(45 + (trendBias - 0.5) * 20, trendBias);
  const { macd, signal: macdSignal, histogram } = calculateMACD(entryPrice, seed + pairSeed);
  const { ma20, ma50 } = calculateMA(entryPrice, seed + pairSeed + 100);
  const bollinger = calculateBollinger(entryPrice, seed + pairSeed + 200);
  const stochastic = calculateStochastic(seed + pairSeed + 300);

  const maPosition = entryPrice > ma20 ? 'above' : 'below';

  // Determine direction
  const { direction, confidence } = determineDirection({
    rsi,
    macdHist: histogram,
    maPosition,
    stochK: stochastic.k,
    stochD: stochastic.d,
    priceAboveMA20: entryPrice > ma20,
  });

  // Calculate final accuracy with timeframe, strategy and category adjustments
  const baseAccuracy = confidence * timeframeMultiplier * volatilityMultiplier;
  const accuracy = Math.max(60, Math.min(97, baseAccuracy + (seededRandom(seed + 999) - 0.3) * 10));

  // Determine risk level
  let riskLevel: 'Low' | 'Medium' | 'High';
  if (accuracy >= 82) riskLevel = 'Low';
  else if (accuracy >= 70) riskLevel = 'Medium';
  else riskLevel = 'High';

  // RSI Signal
  let rsiSignal = 'Neutral';
  if (rsi < 30) rsiSignal = 'Oversold (Buy)';
  else if (rsi < 40) rsiSignal = 'Approaching Oversold';
  else if (rsi > 70) rsiSignal = 'Overbought (Sell)';
  else if (rsi > 60) rsiSignal = 'Approaching Overbought';

  // MACD Signal
  let macdSignalText = 'Neutral';
  if (histogram > 0 && macd > macdSignal) macdSignalText = 'Bullish Crossover';
  else if (histogram < 0 && macd < macdSignal) macdSignalText = 'Bearish Crossover';

  // MA Signal
  const maSignal = ma20 > ma50 ? 'Bullish (Golden Cross)' : 'Bearish (Death Cross)';

  // Bollinger Position
  const bollingerRange = bollinger.upper - bollinger.lower;
  const bollingerPosition = bollingerRange > 0
    ? ((entryPrice - bollinger.lower) / bollingerRange * 100).toFixed(1)
    : '50.0';

  // Stochastic Signal
  let stochSignal = 'Neutral';
  if (stochastic.k < 20 && stochastic.d < 20) stochSignal = 'Oversold';
  else if (stochastic.k > 80 && stochastic.d > 80) stochSignal = 'Overbought';
  else if (stochastic.k > stochastic.d) stochSignal = 'Bullish';
  else stochSignal = 'Bearish';

  return {
    direction,
    accuracy: parseFloat(accuracy.toFixed(1)),
    riskLevel,
    rsi: parseFloat(rsi.toFixed(2)),
    macd,
    macdSignal,
    ma20,
    ma50,
    entryPrice,
    confidence: parseFloat(accuracy.toFixed(1)),
    pairCategory,
    indicators: {
      rsi: { value: parseFloat(rsi.toFixed(2)), signal: rsiSignal },
      macd: { value: macd, signal: macdSignalText, histogram },
      ma: { value20: ma20, value50: ma50, signal: maSignal },
      bollinger: { upper: bollinger.upper, lower: bollinger.lower, middle: bollinger.middle, position: `${bollingerPosition}%` },
      stochastic: { k: stochastic.k, d: stochastic.d, signal: stochSignal },
    },
  };
}

export function getSeedHistorySignals(): Array<{
  id: string;
  broker: string;
  pair: string;
  pairCategory: string;
  timeframe: string;
  direction: string;
  accuracy: number;
  riskLevel: string;
  strategy: string;
  result: string;
  profitLoss: number;
  createdAt: Date;
}> {
  const now = Date.now();
  const allPairs = [
    { symbol: 'USD/BRL OTC', category: 'otc' },
    { symbol: 'EUR/USD', category: 'forex' },
    { symbol: 'BTC/USD', category: 'crypto' },
    { symbol: 'GBP/USD', category: 'forex' },
    { symbol: 'XAU/USD', category: 'commodity' },
    { symbol: 'ETH/USD', category: 'crypto' },
    { symbol: 'SOL/USD', category: 'crypto' },
    { symbol: 'USD/JPY', category: 'forex' },
    { symbol: 'XRP/USD', category: 'crypto' },
    { symbol: 'NAS100/USD', category: 'index' },
  ];
  const brokers = ['Quotex', 'Binomo', 'Pocket Option'];
  const timeframes = ['5s', '10s', '30s', '1m'];
  const strategies = ['Scalping', 'Trend', 'Reversal'];

  return Array.from({ length: 15 }, (_, i) => {
    const seed = now - (i * 120000) - 60000;
    const r = seededRandom(seed / 1000);
    const direction = r > 0.5 ? 'BUY' : 'SELL';
    const accuracy = 65 + seededRandom(seed / 2000) * 30;
    const won = seededRandom(seed / 3000) > 0.35;
    const pairInfo = allPairs[Math.floor(seededRandom(seed / 5000) * allPairs.length)];
    return {
      id: `hist-${i}`,
      broker: brokers[Math.floor(seededRandom(seed / 4000) * brokers.length)],
      pair: pairInfo.symbol,
      pairCategory: pairInfo.category,
      timeframe: timeframes[Math.floor(seededRandom(seed / 6000) * timeframes.length)],
      direction,
      accuracy: parseFloat(accuracy.toFixed(1)),
      riskLevel: accuracy >= 82 ? 'Low' : accuracy >= 70 ? 'Medium' : 'High',
      strategy: strategies[Math.floor(seededRandom(seed / 7000) * strategies.length)],
      result: won ? 'WIN' : 'LOSS',
      profitLoss: won ? parseFloat((2 + seededRandom(seed / 8000) * 8).toFixed(2)) : parseFloat(-(1 + seededRandom(seed / 9000) * 3).toFixed(2)),
      createdAt: new Date(seed),
    };
  });
}
