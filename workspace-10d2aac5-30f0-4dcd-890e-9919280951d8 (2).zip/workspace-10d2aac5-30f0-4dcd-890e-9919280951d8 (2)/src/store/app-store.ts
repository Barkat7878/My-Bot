import { create } from 'zustand';

export type ViewType = 'signals' | 'dashboard' | 'history' | 'pricing' | 'settings' | 'auth';

export interface PairData {
  id: string;
  symbol: string;
  name: string;
  category: string;
  basePrice: number;
  pipSize: number;
}

export interface PairCategory {
  name: string;
  count: number;
}

interface TradingSignal {
  id: string;
  broker: string;
  pair: string;
  pairCategory?: string;
  timeframe: string;
  direction: 'BUY' | 'SELL';
  accuracy: number;
  riskLevel: 'Low' | 'Medium' | 'High';
  strategy: string;
  rsi: number;
  macd: number;
  macdSignal: number;
  ma20: number;
  ma50: number;
  entryPrice: number;
  confidence: number;
  indicators: {
    rsi: { value: number; signal: string };
    macd: { value: number; signal: string; histogram: number };
    ma: { value20: number; value50: number; signal: string };
    bollinger: { upper: number; lower: number; middle: number; position: string };
    stochastic: { k: number; d: number; signal: string };
  };
  timestamp?: string;
  result?: string;
  profitLoss?: number;
  createdAt?: string;
}

interface HistoryStats {
  total: number;
  wins: number;
  losses: number;
  winRate: number;
  totalProfit: number;
  avgAccuracy: number;
}

interface User {
  id: string;
  email: string;
  name: string;
  plan: string;
  totalTrades: number;
  wins: number;
  losses: number;
  profit: number;
  apiKey?: string;
  secretKey?: string;
  winRate?: number;
  createdAt?: string;
}

interface AppState {
  // Navigation
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;

  // Auth
  user: User | null;
  token: string | null;
  isAuthLoading: boolean;
  setUser: (user: User | null) => void;
  setToken: (token: string | null) => void;
  setAuthLoading: (loading: boolean) => void;

  // Signal Configuration
  selectedBroker: string;
  selectedPair: string;
  selectedPairCategory: string;
  selectedTimeframe: string;
  selectedStrategy: string;
  pairs: PairData[];
  pairCategories: PairCategory[];
  setSelectedBroker: (broker: string) => void;
  setSelectedPair: (pair: string) => void;
  setSelectedPairCategory: (category: string) => void;
  setSelectedTimeframe: (timeframe: string) => void;
  setSelectedStrategy: (strategy: string) => void;
  setPairs: (pairs: PairData[]) => void;
  setPairCategories: (categories: PairCategory[]) => void;

  // Signal State
  currentSignal: TradingSignal | null;
  isGenerating: boolean;
  signalHistory: TradingSignal[];
  historyStats: HistoryStats;
  autoRefresh: boolean;
  refreshInterval: number;
  setCurrentSignal: (signal: TradingSignal | null) => void;
  setIsGenerating: (generating: boolean) => void;
  setSignalHistory: (history: TradingSignal[]) => void;
  setHistoryStats: (stats: HistoryStats) => void;
  setAutoRefresh: (refresh: boolean) => void;
  setRefreshInterval: (interval: number) => void;

  // Sound
  soundEnabled: boolean;
  toggleSound: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  // Navigation
  currentView: 'signals',
  setCurrentView: (view) => set({ currentView: view }),

  // Auth
  user: null,
  token: null,
  isAuthLoading: false,
  setUser: (user) => set({ user }),
  setToken: (token) => set({ token }),
  setAuthLoading: (loading) => set({ isAuthLoading: loading }),

  // Signal Configuration
  selectedBroker: 'Quotex',
  selectedPair: 'USD/BRL OTC',
  selectedPairCategory: 'all',
  selectedTimeframe: '30s',
  selectedStrategy: 'Scalping',
  pairs: [],
  pairCategories: [],
  setSelectedBroker: (broker) => set({ selectedBroker: broker }),
  setSelectedPair: (pair) => set({ selectedPair: pair }),
  setSelectedPairCategory: (category) => set({ selectedPairCategory: category }),
  setSelectedTimeframe: (timeframe) => set({ selectedTimeframe: timeframe }),
  setSelectedStrategy: (strategy) => set({ selectedStrategy: strategy }),
  setPairs: (pairs) => set({ pairs }),
  setPairCategories: (categories) => set({ pairCategories: categories }),

  // Signal State
  currentSignal: null,
  isGenerating: false,
  signalHistory: [],
  historyStats: { total: 0, wins: 0, losses: 0, winRate: 0, totalProfit: 0, avgAccuracy: 0 },
  autoRefresh: true,
  refreshInterval: 30,
  setCurrentSignal: (signal) => set({ currentSignal: signal }),
  setIsGenerating: (generating) => set({ isGenerating: generating }),
  setSignalHistory: (history) => set({ signalHistory: history }),
  setHistoryStats: (stats) => set({ historyStats: stats }),
  setAutoRefresh: (refresh) => set({ autoRefresh: refresh }),
  setRefreshInterval: (interval) => set({ refreshInterval: interval }),

  // Sound
  soundEnabled: true,
  toggleSound: () => set((state) => ({ soundEnabled: !state.soundEnabled })),
}));
